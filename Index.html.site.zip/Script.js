/* ==================================
   DEMESTRE RENOVATION
   PREMIUM JS
================================== */

/* ==========
   LOADER
========== */

window.addEventListener("load", () => {

    const loader = document.getElementById("loader");

    setTimeout(() => {

        loader.style.opacity = "0";

        loader.style.visibility = "hidden";

    }, 1800);

});

/* ==========
   HEADER SCROLL
========== */

const header = document.getElementById("header");

window.addEventListener("scroll", () => {

    if (window.scrollY > 80) {

        header.classList.add("scrolled");

    } else {

        header.classList.remove("scrolled");

    }

});

/* ==========
   COMPTEURS
========== */

const counters = document.querySelectorAll(".counter");

const startCounter = () => {

    counters.forEach(counter => {

        const target = +counter.dataset.target;

        const updateCounter = () => {

            const current = +counter.innerText;

            const increment = target / 80;

            if (current < target) {

                counter.innerText =
                    Math.ceil(current + increment);

                setTimeout(updateCounter, 25);

            } else {

                counter.innerText = target + "+";

            }

        };

        updateCounter();

    });

};

let counterStarted = false;

window.addEventListener("scroll", () => {

    const stats = document.querySelector(".stats");

    if (!stats) return;

    const trigger = stats.offsetTop - 500;

    if (window.scrollY > trigger && !counterStarted) {

        startCounter();

        counterStarted = true;

    }

});

/* ==========
   ANIMATION AU SCROLL
========== */

const revealElements = document.querySelectorAll(
    ".service-card, .gallery-grid img, .review-card, .why-card, .stat-card"
);

revealElements.forEach(el => {
    el.classList.add("reveal");
});

function revealOnScroll() {

    const reveals =
        document.querySelectorAll(".reveal");

    reveals.forEach(el => {

        const windowHeight =
            window.innerHeight;

        const elementTop =
            el.getBoundingClientRect().top;

        const revealPoint = 120;

        if (elementTop < windowHeight - revealPoint) {

            el.classList.add("active");

        }

    });

}

window.addEventListener(
    "scroll",
    revealOnScroll
);

revealOnScroll();

/* ==========
   FAQ ACCORDEON
========== */

const questions =
    document.querySelectorAll(".faq-question");

questions.forEach(question => {

    question.addEventListener("click", () => {

        const answer =
            question.nextElementSibling;

        const isOpen =
            answer.style.maxHeight;

        document
            .querySelectorAll(".faq-answer")
            .forEach(item => {

                item.style.maxHeight = null;

            });

        if (!isOpen) {

            answer.style.maxHeight =
                answer.scrollHeight + "px";

        }

    });

});

/* ==========
   GALERIE LIGHTBOX
========== */

const galleryImages =
    document.querySelectorAll(".gallery-grid img");

const lightbox =
    document.createElement("div");

lightbox.id = "lightbox";

lightbox.innerHTML = `
<img src="" alt="">
`;

document.body.appendChild(lightbox);

galleryImages.forEach(image => {

    image.addEventListener("click", () => {

        lightbox.classList.add("active");

        lightbox.querySelector("img").src =
            image.src;

    });

});

lightbox.addEventListener("click", () => {

    lightbox.classList.remove("active");

});

/* ==========
   SCROLL FLUIDE
========== */

document
.querySelectorAll('a[href^="#"]')
.forEach(anchor => {

    anchor.addEventListener(
        "click",
        function (e) {

            e.preventDefault();

            const target =
                document.querySelector(
                    this.getAttribute("href")
                );

            if(target){

                target.scrollIntoView({

                    behavior: "smooth"

                });

            }

        }
    );

});

/* ==========
   FORMULAIRE
========== */

const form =
    document.querySelector(".contact-form");

if(form){

    form.addEventListener("submit", e => {

        e.preventDefault();

        alert(
            "Merci pour votre demande. Demestre Rénovation vous recontactera rapidement."
        );

        form.reset();

    });

}

/* ==========
   PARALLAX HERO
========== */

window.addEventListener("scroll", () => {

    const hero =
        document.querySelector(".hero");

    if(hero){

        hero.style.backgroundPositionY =
            window.scrollY * 0.4 + "px";

    }

});

/* ==========
   ANIMATION TITRE HERO
========== */

const heroTitle =
    document.querySelector(".hero h1");

if(heroTitle){

    heroTitle.animate(

        [

            {
                opacity:0,
                transform:"translateY(40px)"
            },

            {
                opacity:1,
                transform:"translateY(0)"
            }

        ],

        {

            duration:1500,

            easing:"ease-out"

        }

    );

}